import React, { Component } from 'react';
// import logo from './logo.svg';
import './App.css';
import ListaNoticias from './components/ListaNoticias';
import SearchBox from './components/SearchBox';
import axios from 'axios'
//  import FiltrosBox from './components/FiltrosBox';
//import NewsRest from './data/datanews';
import { categorias, paises } from './data/data';
import Select from 'react-select';




class App extends Component {

  state = {
    isLoading: false,
    articles: [],
    query: '',
    pais: '',
    categoria: '',
  
    
  }

  componentDidMount() {
    this.search(null)
  }


  search = async (value) => {

    let apiURL = "https://localhost:44395/api/Articuloes"

    if (value != null) {
      apiURL = "https://localhost:44395/api/Articuloes/" + value
    }

    axios.get(apiURL) 
      .then((res) => {
        this.setState({
          articles: res.data,
          isLoading: false,
          q: value,
          country: this.state.pais,
          category: this.state.categoria,
        })
      })



  }

  setCountry = (option) => {
    this.setState({
      pais: option.value
    });
  }
  setCategory = (option) => {
    this.setState({
      categoria: option.value
    });
  }


  render() {

    return (
      <div className="App container">
        <header>
          <h1>
            WORLD NEWS
         </h1>
        </header>
       
        <Select options={paises} placeholder='Select country' onChange={this.setCountry} />
        <div style={{ height: "10px" }} />
        <Select options={categorias} placeholder='Select category' onChange={this.setCategory} />
        <div style={{ height: "10px" }} />
        <SearchBox onSearch={this.search} />
        <ListaNoticias isLoading={this.state.isLoading} articles={this.state.articles} />
      </div>
    );
  }
}

export default App;
